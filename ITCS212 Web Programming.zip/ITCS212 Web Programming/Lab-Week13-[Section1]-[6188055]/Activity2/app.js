/* Import modules here: express, dotenv, router */
const express = require('express');
const app = express();
const path = require('path');
const router = express.Router();
const dotenv = require('dotenv');
dotenv.config();
app.use(express.urlencoded({ extended: true }));
app.use('/', router);

/* Connection to MySQL */
const mysql = require('mysql');
var connection = mysql.createConnection({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USERNAME,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE
});
/* Connect to DB */
connection.connect(function (err) {
    if (err) throw err;
    console.log("Connected DB: " + process.env.MYSQL_DATABASE);
});
/* Run Server */

router.get('/', function (req, res) {

    connection.connect(function (err) {
        //if (err) throw err;
        console.log("Connected DB:" + process.env.MYSQL_DATABASE);
        /* Prepare HTML */
        var output = '<!DOCTYPE html><html lang="en">';
        output += "<head><title>Student List</title></head><body>";
        output += "<h1 color=blue>Student List</h1><ul>";
        output += '<form action="/"method="POST">'
        output += '<input type="text" class="form-control" id="StudentID" name="StudentID" placeholder="Student ID" required>'
        output += '<br><input type="text" class="form-control" id="Firstname" name="Firstname" placeholder="First name" required>'
        output += '<br><input type="text" class="form-control" id="Lastname" name="Lastname" placeholder="Last name" required>'
        output += '<br><input type="text" class="form-control" id="Phone" name="Phone" placeholder="Phone number" required>'
        output += '<br> <input type="date" class="form-control" id="DoB" name="DoB" required>'
        output += '<button type="submit" value="Submit" class="btn btn-info btn-block rounded-0 py-2">Submit</button>'
        output += "</form><table border=1><tr><th>Name</th><th>DoB</th><th>Mobile</th></tr>"
        let sql = "SELECT * FROM personal_info"; /* SQL SELECT */
        const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
        connection.query(sql, function (err, result) {
            if (err) throw err;
            console.log("Retrieve people list...")
            result.forEach(people => {
                output += "<tr><td>" + people.Firstname + people.Lastname + "</td><td>" + people.DoB.getDate() + "-" + months[people.DoB.getMonth()] + "-" + people.DoB.getFullYear() + "</td><td>" + people.Phone + "</td></tr>";

            });
            output += "</table></ul></body></html>";

            res.send(output);
            res.end();
            //connection.end();
        });
    });
});

router.post('/', function (req, res) {
    /* Use name from the form to get the value */
    const Firstname = req.body.Firstname;
    const Lastname = req.body.Lastname;
    const StudentID = req.body.StudentID;
    const Phone = req.body.Phone;
    const DoB = req.body.DoB;
    //console.log(`Form submitted by ${name}`);
    let sql = `INSERT INTO personal_info VALUES ('${StudentID}','${Firstname}', '${Lastname}', '${DoB}','${Phone}')`;
    connection.query(sql, function (err, result) {
        if (err) throw err;
        console.log(result.affectedRows + " record inserted");
    });

     //if (err) throw err;
     console.log("Connected DB:" + process.env.MYSQL_DATABASE);
     /* Prepare HTML */
     var output = '<!DOCTYPE html><html lang="en">';
     output += "<head><title>Student List</title></head><body>";
     output += "<h1 color=blue>Student List</h1><ul>";
     output += '<form action="/"method="POST">'
     output += '<input type="text" class="form-control" id="StudentID" name="StudentID" placeholder="Student ID" required>'
     output += '<br><input type="text" class="form-control" id="Firstname" name="Firstname" placeholder="First name" required>'
     output += '<br><input type="text" class="form-control" id="Lastname" name="Lastname" placeholder="Last name" required>'
     output += '<br><input type="text" class="form-control" id="Phone" name="Phone" placeholder="Phone number" required>'
     output += '<br> <input type="date" class="form-control" id="DoB" name="DoB" required>'
     output += '<button type="submit" value="Submit" class="btn btn-info btn-block rounded-0 py-2">Submit</button>'
     output += "</form><table border=1><tr><th>Name</th><th>DoB</th><th>Mobile</th></tr>"
      sql = "SELECT * FROM personal_info"; /* SQL SELECT */
     const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
     connection.query(sql, function (err, result) {
         if (err) throw err;
         console.log("Retrieve people list...")
         result.forEach(people => {
             output += "<tr><td>" + people.Firstname + people.Lastname + "</td><td>" + people.DoB.getDate() + "-" + months[people.DoB.getMonth()] + "-" + people.DoB.getFullYear() + "</td><td>" + people.Phone + "</td></tr>";

         });
         output += "</table></ul></body></html>";

         res.send(output);
         res.end();
         //connection.end();
     });
});
app.listen(process.env.PORT, function () {
    console.log("Server listening at Port " + process.env.PORT);
});

