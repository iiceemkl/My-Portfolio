/* Express with Routing */
const path = require('path');
const express = require('express');
const app = express();
    app.get('/',function(req,res)
    {
            res.sendFile(path.join(__dirname+'/index.html'));
            //__dirname : It will resolve to your project folder.
    });
    app.get('/me',function(req,res)
    {
        res.sendFile(path.join(__dirname+'/me.html'));
    });
    /* And more pages here :) */
    app.get('/you',function(req,res)
    {
        res.sendFile(path.join(__dirname+'/you.html'));
    });
    app.get('/*',function(req,res){
        res.sendFile(path.join(__dirname+'/errorcase.html'));
    });
app.listen(8081);
console.log('Running at Port 8081');