const API_KEY = "AIzaSyDo6zJMFtggjCH4tY1FTfesLW8AAD-iUY4";

//This is the form for listing the video//
function videoCard(title, videoId, thumbnails) 
 {
    return `
    <div class="card">
    <p>Title: ${title}</p>
    <img src="${thumbnails.medium.url}">
    <p>URL: <a href="http://www.youtube.com/embed/${videoId}">www.youtube.com/embed/${videoId}</a></p>
    </div>`;
 }

// Get the youtube data Application Programming Interface or which call API from Google API
function GetYouTubeAPI(text)
 {
  $("#loading").show();
  const URL = `https://content.googleapis.com/youtube/v3/search?part=snippet&maxResults=21&q=${text}&type=video&key=${API_KEY}`;
  $.get(URL, function({ items }, status) 
  { 
    items.map(function(value) 
    {
      $("#list-videos").append(videoCard(value.snippet.title,value.id.videoId,value.snippet.thumbnails));
    });    
  });
 }

$(document).ready(function()
 {
  // For click function that make us be able to click on search
  $("#btn-search").click(function() 
  {
    const text = $("#input-search").val();
    $("#list-videos").empty();
    GetYouTubeAPI(text);
  });
  // For key search
  $("#input-search").change(function() 
  {
    const text = $(this).val();
    $("#list-videos").empty();
    GetYouTubeAPI(text);
  });
 });