function doIt()
{
    // Variables for HTML element DOM references.
    var num1Ref, num2Ref, num3Ref, answerRef, title;
    var num4Ref, num5Ref, num6Ref, answersRef, titles;
    
    // Variables declarations.
    var num1, num2, num3, answer, ti; 
    var num4, num5, num6, answers, tis; 
    
    // Get references to DOM elements.
    num1Ref = document.getElementById("num1");
    num2Ref = document.getElementById("num2");
    num3Ref = document.getElementById("num3");
    answerRef = document.getElementById("answer");
    title = document.getElementById("ti");

    num4Ref = document.getElementById("num4");
    num5Ref = document.getElementById("num5");
    num6Ref = document.getElementById("num6");
    answersRef = document.getElementById("answers");
    titles = document.getElementById("tis");



    // Convert strings to numbers, e.g., "21" to 21.
    num1 = Number(num1Ref.value);
    num2 = Number(num2Ref.value);
    num3 = Number(num3Ref.value);
    num4 = Number(num4Ref.value);
    num5 = Number(num5Ref.value);
    num6 = Number(num6Ref.value);

    
    // Perform addition operation then assignment operation
    answer = num1 + num2 + num3; 
    answers = num4 - num5 - num6;

    // Update "answer" label DOM to show result using "innerText" property. innerText is a property of label tag.
    answerRef.innerText = answer;
    
    if (answer >= 0)
    {
        // Value of answer is positive.
        // Set the class of the answer label to "positive".
        answerRef.className = "positive";
    }
    else
    {
        // Value of answer is not positive, i.e., negative.
        // Set the class of the answer label to "negative".
        answerRef.className = "negative";
    }

    
    if( answer % 2 == 0)
    {
        title.innerText = "(even)";
        title.className = "even";
    }
    else
    {
        title.innerText = "(odd)";
        title.className= "odd";
    }

}

function doIts()
{
    // Variables for HTML element DOM references.
    var num1Ref, num2Ref, num3Ref, answerRef, title;
    var num4Ref, num5Ref, num6Ref, answersRef, titles;
    
    // Variables declarations.
    var num1, num2, num3, answer, ti; 
    var num4, num5, num6, answers, tis; 
    
    // Get references to DOM elements.
    num1Ref = document.getElementById("num1");
    num2Ref = document.getElementById("num2");
    num3Ref = document.getElementById("num3");
    answerRef = document.getElementById("answer");
    title = document.getElementById("ti");

    num4Ref = document.getElementById("num4");
    num5Ref = document.getElementById("num5");
    num6Ref = document.getElementById("num6");
    answersRef = document.getElementById("answers");
    titles = document.getElementById("tis");



    // Convert strings to numbers, e.g., "21" to 21.
    num1 = Number(num1Ref.value);
    num2 = Number(num2Ref.value);
    num3 = Number(num3Ref.value);
    num4 = Number(num4Ref.value);
    num5 = Number(num5Ref.value);
    num6 = Number(num6Ref.value);

    
    // Perform addition operation then assignment operation
    answer = num1 + num2 + num3; 
    answers = num4 - num5 - num6;

    // Update "answer" label DOM to show result using "innerText" property. innerText is a property of label tag.
    
    answersRef.innerText = answers;
    

    if (answers >= 0)
    {
        // Value of answer is positive.
        // Set the class of the answer label to "positive".
        answersRef.className = "positive";
    }
    else
    {
        // Value of answer is not positive, i.e., negative.
        // Set the class of the answer label to "negative".
        answersRef.className = "negative";
    }
    
    if( answers % 2 == 0)
    {
        titles.innerText = "(even)";
        titles.className = "even";
    }
    else
    {
        titles.innerText = "(odd)";
        titles.className = "odd";
    }
}
    
    
